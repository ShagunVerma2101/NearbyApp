//
//  VenueListViewModel.swift
//  Nearby
//
//  Created by Shagun Verma on 25/11/23.
//

import Foundation
import CoreLocation

protocol VenueListViewModelProtocol {
  var numberOfRows: Int {get}
  var searchText: String {get set}
  func getVenuesNearby(location: CLLocationCoordinate2D)
  func getItem(at indexPath: IndexPath) -> VenueInfo
  func filterData()
  var reloadData:(() -> Void)? {get set}
}

final class VenueListViewModel: VenueListViewModelProtocol {
    
  let networkManager: NetworkManager
  let defaultsManager: UserDefaultsManager
  private var filteredData: [VenueInfo] = []
  private var data:[VenueInfo] = []
  var reloadData:(() -> Void)?
 
  // Pagination properties
  private var currentPage = 1
  private let itemsPerPage = 10
  private var isFetchingData = false
  
  init(networkManager: NetworkManager, defaultsManager: UserDefaultsManager) {
    self.networkManager = networkManager
    self.defaultsManager = defaultsManager
  }
  
  var numberOfRows: Int {
          return isSearching ? filteredData.count : data.count
      }

      func getItem(at indexPath: IndexPath) -> VenueInfo {
          return isSearching ? filteredData[indexPath.row] : data[indexPath.row]
      }

      // Search functionality
      var isSearching: Bool {
          return !searchText.isEmpty
      }

    var searchText: String = ""

    func filterData() {
        filteredData = data.filter { $0.name.lowercased().contains(searchText.lowercased()) }
    }
  
  func updateVenueList(venues:[VenueInfo]) {
      isFetchingData = false
      data = data+venues
      reloadData?()
  }
  
  func getVenuesNearby(location: CLLocationCoordinate2D) {
      let venuesList = defaultsManager.getVenuesList()
      if (venuesList.isEmpty) {
          // Fetch and store the venues if the app is run for the first time
          fetchVenues(location: location)
      } else {
          updateVenueList(venues: venuesList)
          fetchVenues(location: location)
      }
  }

  func fetchVenues(location: CLLocationCoordinate2D) {
    
    guard !isFetchingData else { return }

    isFetchingData = true

    let url = "https://api.seatgeek.com/2/venues?client_id=Mzg0OTc0Njl8MTcwMDgxMTg5NC44MDk2NjY5&per_page=\(itemsPerPage)&page=\(currentPage)&lat=\(location.latitude)&lon=\(location.longitude)"
    networkManager.fetchData(from: url, completion: { result in
      switch result {
      case .success(let data):
          // Handle the data

            do {
              let venueList = try JSONDecoder().decode(VenueList.self, from: data)
              self.currentPage += 1
//              self.defaultsManager.updateVenuesList(data: data)
              self.updateVenueList(venues: venueList.venues)
            } catch {
                print("Error decoding JSON: \(error)")
            }

      case .failure(let error):
          // Handle the error
          print("Error: \(error)")
      }
    })
  }
  
  func getCurrentLocation(){
    
  }
}


