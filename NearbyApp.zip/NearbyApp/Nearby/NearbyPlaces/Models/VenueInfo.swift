//
//  VenueInfo.swift
//  Nearby
//
//  Created by Shagun Verma on 25/11/23.
//

import Foundation

struct VenueList: Codable{
  let venues: [VenueInfo]
  let meta: Meta
}

struct VenueInfo: Codable {
    let state: String?
    let nameV2: String
    let postalCode: String?
    let name: String
    let links: [String]
    let timezone: String?
    let url: String
    let score: Int
    let location: Location
    let address: String?
    let country: String
    let hasUpcomingEvents: Bool
    let numUpcomingEvents: Int
    let city: String
    let slug: String
    let extendedAddress: String
    let stats: Stats
    let id: Int
    let popularity: Int
    let accessMethod: String?
    let metroCode: Int
    let capacity: Int
    let displayLocation: String

    enum CodingKeys: String, CodingKey {
        case state, nameV2 = "name_v2", postalCode = "postal_code", name, links, timezone, url, score, location, address, country, hasUpcomingEvents = "has_upcoming_events", numUpcomingEvents = "num_upcoming_events", city, slug, extendedAddress = "extended_address", stats, id, popularity, accessMethod = "access_method", metroCode = "metro_code", capacity, displayLocation = "display_location"
    }
}

struct Location: Codable {
    let lat: Double
    let lon: Double
}

struct Stats: Codable {
    let eventCount: Int

    enum CodingKeys: String, CodingKey {
        case eventCount = "event_count"
    }
}

struct Meta: Codable {
    let total: Int
    let took: Int
    let page: Int
    let perPage: Int
    let geolocation: Geolocation
  
  enum CodingKeys: String, CodingKey {
          case total, took, page, geolocation
          case perPage = "per_page"
      }
}

struct Geolocation: Codable {
    let lat: Double
    let lon: Double
    let city: String
    let state: String
    let country: String
    let postalCode: String?
    let displayName: String
    let metroCode: String?
    let range: String
  
  enum CodingKeys: String, CodingKey {
    case lat, lon, city, state, country, range
    case postalCode = "postal_code"
    case displayName = "display_name"
    case metroCode = "metro_code"
      }
}
