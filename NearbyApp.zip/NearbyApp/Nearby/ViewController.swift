//
//  ViewController.swift
//  Nearby
//
//  Created by Shagun Verma on 25/11/23.
//

import UIKit
import CoreLocation

class ViewController: UIViewController {
  
  var locationManager: CLLocationManager!
  var venueListViewModel: VenueListViewModelProtocol = VenueListViewModel(networkManager: NetworkManager(), defaultsManager: UserDefaultsManager())
  
  private let tableView = UITableView()
  private let searchBar = UISearchBar()
  private var currentLocation = CLLocationCoordinate2D()
  let sliderFooterView = UIView()
   let slider = UISlider()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
    
    locationManager = CLLocationManager()
    locationManager.delegate = self
    locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
    
    venueListViewModel.reloadData = {[weak self] in
      guard let self = self else {return}
      DispatchQueue.main.async {
        self.tableView.reloadData()

      }
    }
    
    setupSearchBar()
    setupTableView()
    setupSlider()

    DispatchQueue.main.async {[weak self] in
      guard let self = self else {return}
      
      if CLLocationManager.locationServicesEnabled() {
        self.locationManager.requestWhenInUseAuthorization()
        self.locationManager.startUpdatingLocation()
      } else {
        // Handle the case where location services are not enabled
        print("Location services are not enabled")
      }
      
    }
    
  }
  
  
  private func setupSearchBar() {
    searchBar.delegate = self
    searchBar.placeholder = "Search"
    searchBar.searchBarStyle = .minimal
    
    view.addSubview(searchBar)
    
    searchBar.translatesAutoresizingMaskIntoConstraints = false
    NSLayoutConstraint.activate([
      searchBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
      searchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
      searchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor)
    ])
  }
  
  private func setupTableView() {
    tableView.dataSource = self
    tableView.delegate = self

    view.addSubview(tableView)
    
    tableView.translatesAutoresizingMaskIntoConstraints = false
    NSLayoutConstraint.activate([
      tableView.topAnchor.constraint(equalTo: searchBar.bottomAnchor),
      tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
      tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
      tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
    ])
    
    tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
  }
  
  func setupSlider() {
          slider.minimumValue = 0.0
          slider.maximumValue = 100.0
          slider.value = 50.0
          slider.addTarget(self, action: #selector(sliderValueChanged), for: .valueChanged)
      }
  
  func setupFooterView() {
          // Customize the footer view as needed
          sliderFooterView.backgroundColor = UIColor.lightGray
    slider.frame = CGRect(x: 0, y: 0, width: 200, height: 200)
          
          // Add the slider to the footer view
          slider.translatesAutoresizingMaskIntoConstraints = false
          sliderFooterView.addSubview(slider)

          NSLayoutConstraint.activate([
            slider.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            slider.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            slider.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            slider.heightAnchor.constraint(equalToConstant: 150)
          ])

          NSLayoutConstraint.activate([
            slider.leadingAnchor.constraint(equalTo: sliderFooterView.leadingAnchor),
            slider.trailingAnchor.constraint(equalTo: sliderFooterView.trailingAnchor),
            slider.bottomAnchor.constraint(equalTo: sliderFooterView.bottomAnchor),
            slider.topAnchor.constraint(equalTo: sliderFooterView.topAnchor)
          ])

          // Set the table view's tableFooterView to your custom footer view
          self.view.addSubview(slider)
    }
  
  private func fetchNextPage() {
    venueListViewModel.getVenuesNearby(location: currentLocation)
  }
}

extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            if let location = locations.last {
                // Access the user's current location
                let latitude = location.coordinate.latitude
                let longitude = location.coordinate.longitude

                print("Latitude: \(latitude), Longitude: \(longitude)")
                
              self.currentLocation = location.coordinate
                venueListViewModel.getVenuesNearby(location: location.coordinate)
                // Stop updating location to save battery
                locationManager.stopUpdatingLocation()
            }
        }

        func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
            // Handle location update failure
            print("Location update failed with error: \(error.localizedDescription)")
        }
    

  }

// MARK: - UITableViewDelegate
extension ViewController: UITableViewDelegate, UITableViewDataSource, UITableViewDataSourcePrefetching {
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return venueListViewModel.numberOfRows
      }

      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
          let item = venueListViewModel.getItem(at: indexPath)
        
          var contentConfig = UIListContentConfiguration.subtitleCell()
          contentConfig.text = item.name
          contentConfig.secondaryText = item.extendedAddress
          contentConfig.image = UIImage(named: "")
          cell.contentConfiguration = contentConfig
          return cell
      }

      func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          tableView.deselectRow(at: indexPath, animated: true)
          let selectedItem = venueListViewModel.getItem(at: indexPath)
          print("Selected item: \(selectedItem.name)")
      }
  
  // Fetch the next page of data when prefetching indicates it's needed
     func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {
         let needsFetching = indexPaths.contains { $0.row >= venueListViewModel.numberOfRows - 1 }
         if needsFetching {
             fetchNextPage()
         }
     }
}

// MARK: - UISearchBarDelegate
extension ViewController: UISearchBarDelegate {
      func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        venueListViewModel.searchText = searchText
        venueListViewModel.filterData()
          tableView.reloadData()
      }
}

// MARK: - UISlider
extension ViewController {
  @objc func sliderValueChanged() {
          // Handle slider value changes
          print("Slider value: \(slider.value)")
      }
}
