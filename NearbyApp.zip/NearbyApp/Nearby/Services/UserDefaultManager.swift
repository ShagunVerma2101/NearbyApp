//
//  UserDefaultManager.swift
//  Nearby
//
//  Created by Shagun Verma on 25/11/23.
//

import Foundation

private struct Constant {
  static var venues = "venues"
}

class UserDefaultsManager {
  // MARK:- getter functions
  func getVenuesList() -> [VenueInfo] {
    guard let ids = UserDefaults.standard.array(forKey: Constant.venues) as? [VenueInfo]  else { return [] }
    return ids
  }
  
  func updateVenuesList(venues: [VenueInfo])  {
    UserDefaults.standard.set(venues, forKey: Constant.venues)
  }
  
}
