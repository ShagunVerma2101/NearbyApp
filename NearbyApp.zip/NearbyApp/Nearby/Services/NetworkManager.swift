//
//  NetworkManager.swift
//  Nearby
//
//  Created by Shagun Verma on 25/11/23.
//

import UIKit

enum APIError: Error {
    case networkError
    case apiError
    case decodingError
}

final class NetworkManager {
            
    func fetchData(from url: String, completion: @escaping (Result<Data, APIError>) -> Void) {
        guard let url = URL(string: url) else {
            completion(.failure(.apiError))
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let _ = error {
                completion(.failure(.apiError))
                return
            }
            
            guard let _ = response as? HTTPURLResponse else {
                completion(.failure(.apiError))
                return
            }
            
            guard let data = data else {
                completion(.failure(.decodingError))
                return
            }
            
            completion(.success(data))
        }
        
        task.resume()
    }
}
